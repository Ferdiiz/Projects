import pygame

print(pygame.__version__)